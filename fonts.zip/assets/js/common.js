/**
 * Created by Admin on 15-06-2017.
 */

$(document).ready(function () {

//Preloader
    $(window).on('load', function (e) {
        $('#status').fadeOut();
        $('#preloader').delay(350).fadeOut('slow');
        $('body').delay(350).css({'overflow': 'visib    le'});

    })
    //Sticky JS
    $("#main-nav").sticky({topSpacing: 0});

}); 