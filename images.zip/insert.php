<?php
include 'config.php';

$array=$_POST;

//print_r($array);

$table = 'student';

$sql  = "INSERT INTO student";
$sql .= " (`".implode("`, `", array_keys($array))."`)";
$sql .= " VALUES ('".implode("', '", $array)."') ";

$result = executeQuery($sql);


if ($result == 1) {
    echo '1';
} else {
    echo '0';
}

