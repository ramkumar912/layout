<?php
include 'config.php';
$id = $_GET['id'];
?>


<!DOCTYPE html>
<html lang="en">
  <head>
  
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Student Information Management</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	 <link href="css/form.css" rel="stylesheet">

 <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>



  <div class="container">
	<div class="row">
		<h2 class="h2-bg text-center"><span class="h2-bg-white">Student Information Management</span></h2>
		
	</div>
</div>

  <div class="container">
	<div class="row">
	<a href="index.php" class="btn btn-primary btn-xs pull-right"><b>+</b> back</a>
    <div class="col-md-12">
		<div class="form_main">
                <h4 class="heading"><strong>Update</strong> Student Information <span></span></h4>


            <?php
            $value=getQuery("SELECT * From `student` WHERE id=$id ");
            foreach($value as $row){


            ?>
                <div class="form">
                    <form  action="javascript:;" method="post" id="editform" name="editform">
                        <input type="hidden" required="" value="<?php echo $row['id'];?>" name="id" class="id">
                    <input type="text" required="" value="<?php echo $row['name'];?>" name="name" class="txt">
                    <input type="date" required="" value="<?php echo $row['dob'];?>" name="dob" class="date">
                    <input type="text" required="" value="<?php echo $row['regno'];?>" name="regno" class="txt">
                    <input type="text" required="" value="<?php echo $row['fname'];?>" name="fname" class="txt">
					<input type="text" required="" value="<?php echo $row['mname'];?>" name="mname" class="txt">
                	
                     <input type="submit" value="submit" name="submit" name="edit" id="edit" class="edit">
                </form>
            </div>

            <?php
            }
            ?>

            </div>
            </div
	</div>
</div>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>	
	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>


  <script type="text/javascript">
      $('.edit').click(function(){
          var datastring = $("#editform").serialize();
          $.ajax({
              type:"POST",
              url: "update.php",
              data: datastring,
              datatype:"json",
              success: function(data) {
                 // alert(data);
                 alert("updated Data is saved");
                 window.location.href = "index.php";
              },
              error: function() {
                  alert('error handing here');
              }
          });
      });


  </script>
  </body>
</html>


