<?php

//for connection
function getConnection() {
    $con = mysqli_connect("localhost", "root", "", "oops");
   // Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 
    return $con;
}

// For insert, update and delete return int (0 or 1)
function executeQuery($query) {
    $val = 0;
    $con = getConnection();
    $result = mysqli_query($con, $query);
    if (!$result) {
        $val = 0;
    } else {
        $val = 1;
    }
    $con->close();
    return $val;
}

// To display record return as array
function getQuery($query) {
    $result = null;
    $con = getConnection();
    $result = mysqli_query($con, $query);
    if (!$result) {
        echo "Error :" . mysqli_error($con);
    }
    mysqli_close($con);
    return $result;
}

?>