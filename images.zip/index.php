<!DOCTYPE html>
<html lang="en">
  <head>
  
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Student Information Management</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	 <link href="css/form.css" rel="stylesheet">

 <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
<?php include 'config.php'?>  
<div class="container">
	<div class="row">
		<h2 class="h2-bg text-center"><span class="h2-bg-white">Student Information Management</span></h2>
		
	</div>
</div>

<div class="container">
    <div class="row">
	<div class="col-md-12 custyle">
    <table class="table table-striped custab">
    <thead>
    <a href="add.php" class="btn btn-primary btn-xs pull-right"><b>+</b> Add Record</a>
        <tr>
            <th>Sno</th>
            <th>Name</th>
            <th>Date Of Birth</th>
			<th>Register No</th>
			<th>Father Name</th>
			<th>Mother Name</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>

        <?php
        $value=getQuery("SELECT * from student ORDER BY id DESC ");
        foreach($value as $row){
        ?>
            <tr data-id="<?php echo $row['id']; ?>">
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['dob']; ?></td>
				<td><?php echo $row['regno']; ?></td>
				<td><?php echo $row['fname']; ?></td>
				<td><?php echo $row['mname']; ?></td>
                <td class="text-center"><a class='btn btn-info btn-xs' href="edit.php?id=<?php echo $row['id']; ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> <a href="javascript:;" class="btn btn-danger btn-xs delete"><span class="glyphicon glyphicon-remove"></span> Del</a></td>
            </tr>
          <?php
        }

        ?>
    </table>
    </div>
</div>
</div>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>	
	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

<script type="text/javascript">
        $('.delete').click(function(){
           current = $(this);
           id = current.closest('tr').attr('data-id');

          $.ajax({
                type: "POST",
                url:"delete.php",
                dataType: "html",
                data: {id: id},
                success: function (response){
                    alert("Data is deleted");
                    window.location.href = "index.php";
                },
          });

        })

</script>
  </body>
</html>