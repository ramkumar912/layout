<?php
include 'config.php';

$array=$_POST;
///print_r($array);
$id = array_shift($array);
$fields = array();

foreach($array as $field => $val) {
    $fields[] = "$field = '$val'";
}

$sql = "UPDATE student SET " . join(', ', $fields) . " WHERE id = '$id'";

/*$table = 'student';
$sql  = "UPDATE student set";
$sql .= " (`".implode("`, `", array_keys($array))."`)";
$sql .= " VALUES ('".implode("', '", $array)."') WHERE id = '$id'";*/

$result = executeQuery($sql);
if ($result == 1) {
    echo '1';
} else {
    echo '0';
}

