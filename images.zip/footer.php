<div class="container">
  <div class="row">
    <!-- FOOTER -->
    <footer>
	
        <ul class="footer-left">
          <li>Copyright © 1999-2017 <a href="#">ecfirst</a> Inc. All rights reserved.</li>
   
        </ul>
        <ul class="footer-right">    
		 <li><a href="index.php">Back</a></li>
          <li><a href="https://www.ecfirst.com/" target="_blank">Home</a></li>
          <li><a href="https://www.ecfirst.com/consulting-services"  target="_blank">Services</a></li>
          <li><a href="https://www.ecfirst.com/contact/"  target="_blank">Contact</a></li>
        </ul>       
    </footer> 
</div> 
 </div> 