<?php
include 'config.php';

$id=$_POST['id'];

$data = getQuery("delete from student where id = $id");

echo $data;

if ($data) {

    echo '1';

} else {

    echo "0";

}
